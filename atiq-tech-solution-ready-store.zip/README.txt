ATIQ TECH SOLUTION - FREE HOSTING READY STORE
1. Open index.html to preview.
2. Upload index.html to GitHub Pages.
3. Product names/prices are sample data and can be edited in the JavaScript products list.
4. WhatsApp order number: 01797880328.
5. Email: atiqtechsolution@gmail.com
6. Facebook: https://facebook.com/atiqtechsolution
7. Address: Rell Bazar, Lalmonirhat
